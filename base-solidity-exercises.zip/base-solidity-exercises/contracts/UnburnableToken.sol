// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/// @title UnburnableToken
/// @notice Very small claimable token. Tokens cannot be burned.
contract UnburnableToken {
    string private salt = "value";

    mapping(address => uint256) public balances;
    uint256 public totalSupply;
    uint256 public totalClaimed;
    mapping(address => bool) private claimed;

    error TokensClaimed();
    error AllTokensClaimed();
    error UnsafeTransfer(address to);

    constructor() {
        totalSupply = 100_000_000;
    }

    function claim() public {
        if (totalClaimed >= totalSupply) revert AllTokensClaimed();
        if (claimed[msg.sender]) revert TokensClaimed();

        uint256 amount = 1000;
        balances[msg.sender] += amount;
        totalClaimed += amount;
        claimed[msg.sender] = true;
    }

    function safeTransfer(address _to, uint256 _amount) public {
        if (_to == address(0) || _to.balance == 0) revert UnsafeTransfer(_to);
        require(balances[msg.sender] >= _amount, "Insufficient balance");

        balances[msg.sender] -= _amount;
        balances[_to] += _amount;
    }
}
