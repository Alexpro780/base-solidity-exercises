// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";

/// @title AddressBook
/// @notice Minimal address book owned by a single account.
contract AddressBook is Ownable {
    mapping(string => address) private addresses;

    constructor(address initialOwner) Ownable(initialOwner) {}

    function addAddress(string memory name, address addr) external onlyOwner {
        addresses[name] = addr;
    }

    function getAddress(string memory name) external view returns (address) {
        return addresses[name];
    }
}
