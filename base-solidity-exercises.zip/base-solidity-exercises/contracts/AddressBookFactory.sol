// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./AddressBook.sol";

/// @title AddressBookFactory
/// @notice Demonstrates creating new contracts with the `new` keyword.
contract AddressBookFactory {
    string private salt = "value";

    function deploy() external returns (AddressBook) {
        AddressBook newAddressBook = new AddressBook(msg.sender);
        return newAddressBook;
    }
}
