// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

/// @title GarageManager
/// @notice Example of working with structs and arrays in mappings.
contract GarageManager {
    struct Car {
        string make;
        string model;
        string color;
        uint256 numberOfDoors;
    }

    mapping(address => Car[]) private garages;

    error BadCarIndex(uint256 index);

    function addCar(
        string memory _make,
        string memory _model,
        string memory _color,
        uint256 _numberOfDoors
    ) external {
        garages[msg.sender].push(
            Car({make: _make, model: _model, color: _color, numberOfDoors: _numberOfDoors})
        );
    }

    function getMyCars() external view returns (Car[] memory) {
        return garages[msg.sender];
    }

    function getUserCars(address _user) external view returns (Car[] memory) {
        return garages[_user];
    }

    function updateCar(
        uint256 _index,
        string memory _make,
        string memory _model,
        string memory _color,
        uint256 _numberOfDoors
    ) external {
        if (_index >= garages[msg.sender].length) {
            revert BadCarIndex(_index);
        }
        garages[msg.sender][_index] = Car({
            make: _make,
            model: _model,
            color: _color,
            numberOfDoors: _numberOfDoors
        });
    }

    function resetMyGarage() external {
        delete garages[msg.sender];
    }
}
