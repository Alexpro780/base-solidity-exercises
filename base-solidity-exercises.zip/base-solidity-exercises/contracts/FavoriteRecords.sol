// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

/// @title FavoriteRecords
/// @notice Demonstrates mappings, arrays and custom errors.
contract FavoriteRecords {
    mapping(string => bool) private approvedRecords;
    string[] private approvedRecordsIndex;

    mapping(address => mapping(string => bool)) public userFavorites;
    mapping(address => string[]) private userFavoritesIndex;

    error NotApproved(string albumName);

    constructor() {
        string[9] memory albums = [
            "Thriller",
            "Back in Black",
            "The Bodyguard",
            "The Dark Side of the Moon",
            "Their Greatest Hits (1971-1975)",
            "Hotel California",
            "Come On Over",
            "Rumours",
            "Saturday Night Fever"
        ];

        for (uint256 i = 0; i < albums.length; i++) {
            approvedRecords[albums[i]] = true;
            approvedRecordsIndex.push(albums[i]);
        }
    }

    function getApprovedRecords() external view returns (string[] memory) {
        return approvedRecordsIndex;
    }

    function addRecord(string memory _albumName) external {
        if (!approvedRecords[_albumName]) {
            revert NotApproved(_albumName);
        }

        if (!userFavorites[msg.sender][_albumName]) {
            userFavorites[msg.sender][_albumName] = true;
            userFavoritesIndex[msg.sender].push(_albumName);
        }
    }

    function getUserFavorites(address _user) external view returns (string[] memory) {
        return userFavoritesIndex[_user];
    }

    function resetUserFavorites() external {
        string[] storage list = userFavoritesIndex[msg.sender];
        for (uint256 i = 0; i < list.length; i++) {
            delete userFavorites[msg.sender][list[i]];
        }
        delete userFavoritesIndex[msg.sender];
    }
}
