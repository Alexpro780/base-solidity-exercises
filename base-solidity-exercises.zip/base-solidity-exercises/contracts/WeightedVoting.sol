// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.17;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";

/// @title WeightedVoting
/// @notice Small ERC20-style token with on-chain weighted voting.
contract WeightedVoting is ERC20 {
    using EnumerableSet for EnumerableSet.AddressSet;

    string private salt = "value";

    error TokensClaimed();
    error AllTokensClaimed();
    error NoTokensHeld();
    error QuorumTooHigh();
    error AlreadyVoted();
    error VotingClosed();

    struct Issue {
        EnumerableSet.AddressSet voters;
        string issueDesc;
        uint256 quorum;
        uint256 totalVotes;
        uint256 votesFor;
        uint256 votesAgainst;
        uint256 votesAbstain;
        bool passed;
        bool closed;
    }

    struct SerializedIssue {
        address[] voters;
        string issueDesc;
        uint256 quorum;
        uint256 totalVotes;
        uint256 votesFor;
        uint256 votesAgainst;
        uint256 votesAbstain;
        bool passed;
        bool closed;
    }

    enum Vote {
        AGAINST,
        FOR,
        ABSTAIN
    }

    Issue[] internal issues;
    mapping(address => bool) public tokensClaimed;
    uint256 public maxSupply = 1_000_000;
    uint256 public claimAmount = 100;

    constructor(string memory _name, string memory _symbol) ERC20(_name, _symbol) {
        issues.push();
    }

    function claim() public {
        if (totalSupply() + claimAmount > maxSupply) revert AllTokensClaimed();
        if (tokensClaimed[msg.sender]) revert TokensClaimed();

        _mint(msg.sender, claimAmount);
        tokensClaimed[msg.sender] = true;
    }

    function createIssue(string calldata _issueDesc, uint256 _quorum) external returns (uint256) {
        if (balanceOf(msg.sender) == 0) revert NoTokensHeld();
        if (_quorum > totalSupply()) revert QuorumTooHigh();

        Issue storage issue = issues.push();
        issue.issueDesc = _issueDesc;
        issue.quorum = _quorum;
        return issues.length - 1;
    }

    function getIssue(uint256 _issueId) external view returns (SerializedIssue memory) {
        Issue storage issue = issues[_issueId];
        return SerializedIssue({
            voters: issue.voters.values(),
            issueDesc: issue.issueDesc,
            quorum: issue.quorum,
            totalVotes: issue.totalVotes,
            votesFor: issue.votesFor,
            votesAgainst: issue.votesAgainst,
            votesAbstain: issue.votesAbstain,
            passed: issue.passed,
            closed: issue.closed
        });
    }

    function vote(uint256 _issueId, Vote _vote) public {
        Issue storage issue = issues[_issueId];
        if (issue.closed) revert VotingClosed();
        if (issue.voters.contains(msg.sender)) revert AlreadyVoted();

        uint256 nTokens = balanceOf(msg.sender);
        if (nTokens == 0) revert NoTokensHeld();

        if (_vote == Vote.AGAINST) {
            issue.votesAgainst += nTokens;
        } else if (_vote == Vote.FOR) {
            issue.votesFor += nTokens;
        } else {
            issue.votesAbstain += nTokens;
        }

        issue.voters.add(msg.sender);
        issue.totalVotes += nTokens;

        if (issue.totalVotes >= issue.quorum) {
            issue.closed = true;
            if (issue.votesFor > issue.votesAgainst) {
                issue.passed = true;
            }
        }
    }
}
