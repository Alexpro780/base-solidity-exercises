// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/// @title BasicMath
/// @notice Small contract demonstrating simple arithmetic with overflow / underflow flags.
contract BasicMath {
    uint256 constant MAX_INT = type(uint256).max;

    /// @notice Adds two numbers and returns result + overflow flag.
    function adder(uint256 _a, uint256 _b) external pure returns (uint256 result, bool overflowed) {
        if (_b > MAX_INT - _a) {
            return (0, true);
        }
        return (_a + _b, false);
    }

    /// @notice Subtracts b from a and returns result + underflow flag.
    function subtractor(uint256 _a, uint256 _b) external pure returns (uint256 result, bool underflowed) {
        if (_b > _a) {
            return (0, true);
        }
        return (_a - _b, false);
    }
}
