// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

/// @title Employee
abstract contract Employee {
    uint256 public idNumber;
    uint256 public managerId;

    constructor(uint256 _idNumber, uint256 _managerId) {
        idNumber = _idNumber;
        managerId = _managerId;
    }

    function getAnnualCost() public view virtual returns (uint256);
}

/// @title Salaried
contract Salaried is Employee {
    uint256 public annualSalary;

    constructor(uint256 _idNumber, uint256 _managerId, uint256 _annualSalary)
        Employee(_idNumber, _managerId)
    {
        annualSalary = _annualSalary;
    }

    function getAnnualCost() public view override returns (uint256) {
        return annualSalary;
    }
}

/// @title Hourly
contract Hourly is Employee {
    uint256 public hourlyRate;

    constructor(uint256 _idNumber, uint256 _managerId, uint256 _hourlyRate)
        Employee(_idNumber, _managerId)
    {
        hourlyRate = _hourlyRate;
    }

    function getAnnualCost() public view override returns (uint256) {
        // 2080 hours = 52 weeks * 40 hours
        return hourlyRate * 2080;
    }
}

/// @title Manager
contract Manager {
    uint256[] public employeeIds;

    function addReport(uint256 _reportId) public {
        employeeIds.push(_reportId);
    }

    function resetReports() public {
        delete employeeIds;
    }
}

/// @title Salesperson
contract Salesperson is Hourly {
    constructor(uint256 _idNumber, uint256 _managerId, uint256 _hourlyRate)
        Hourly(_idNumber, _managerId, _hourlyRate)
    {}
}

/// @title EngineeringManager
contract EngineeringManager is Salaried, Manager {
    constructor(uint256 _idNumber, uint256 _managerId, uint256 _annualSalary)
        Salaried(_idNumber, _managerId, _annualSalary)
    {}
}

/// @title InheritanceSubmission
/// @notice Helper contract to tie together deployed Salesperson and EngineeringManager.
contract InheritanceSubmission {
    address public salesPerson;
    address public engineeringManager;

    constructor(address _salesPerson, address _engineeringManager) {
        salesPerson = _salesPerson;
        engineeringManager = _engineeringManager;
    }
}
