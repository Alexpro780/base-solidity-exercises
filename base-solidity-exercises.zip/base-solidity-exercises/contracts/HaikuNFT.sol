// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/contracts/token/ERC721/ERC721.sol";

/// @title HaikuNFT
/// @notice Simple ERC721 contract for storing and sharing Haiku poems.
contract HaikuNFT is ERC721 {
    struct Haiku {
        address author;
        string line1;
        string line2;
        string line3;
    }

    Haiku[] public haikus;
    mapping(address => mapping(uint256 => bool)) public sharedHaikus;
    uint256 public haikuCounter;
    string private salt = "value";

    error HaikuNotUnique();
    error NotYourHaiku();
    error NoHaikusShared();

    constructor() ERC721("HaikuNFT", "HAIKU") {
        haikuCounter = 1;
    }

    function counter() external view returns (uint256) {
        return haikuCounter;
    }

    function mintHaiku(
        string memory _line1,
        string memory _line2,
        string memory _line3
    ) external {
        // very simple uniqueness check: no identical full haiku
        for (uint256 i = 0; i < haikus.length; i++) {
            Haiku memory h = haikus[i];
            if (
                keccak256(abi.encodePacked(h.line1, h.line2, h.line3)) ==
                keccak256(abi.encodePacked(_line1, _line2, _line3))
            ) {
                revert HaikuNotUnique();
            }
        }

        _safeMint(msg.sender, haikuCounter);
        haikus.push(Haiku({author: msg.sender, line1: _line1, line2: _line2, line3: _line3}));
        haikuCounter++;
    }

    function shareHaiku(uint256 _id, address _to) external {
        require(_id > 0 && _id < haikuCounter, "Invalid haiku id");
        Haiku memory h = haikus[_id - 1];
        if (h.author != msg.sender) revert NotYourHaiku();
        sharedHaikus[_to][_id] = true;
    }

    function getMySharedHaikus() external view returns (Haiku[] memory) {
        uint256 count;
        for (uint256 i = 1; i < haikuCounter; i++) {
            if (sharedHaikus[msg.sender][i]) {
                count++;
            }
        }

        if (count == 0) revert NoHaikusShared();

        Haiku[] memory result = new Haiku[](count);
        uint256 idx;
        for (uint256 i = 1; i < haikuCounter; i++) {
            if (sharedHaikus[msg.sender][i]) {
                result[idx] = haikus[i - 1];
                idx++;
            }
        }
        return result;
    }
}
